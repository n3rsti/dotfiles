import QtQuick
import QtQml
import Quickshell
import ".."
import "../common"

ModuleBox {
    id: clockModule

    required property var clock

    Text {
        text: Qt.formatDateTime(clock.date, Style.clockFormat)

        color: clockModule.hovered ? Style.foregroundHover : Style.foreground

        font.family: Style.fontFamily
        font.pixelSize: Style.fontSize
        font.weight: Style.fontWeight

        verticalAlignment: Text.AlignVCenter
    }
}
